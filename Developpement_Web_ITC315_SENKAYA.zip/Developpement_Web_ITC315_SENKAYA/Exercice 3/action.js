

function testFonctionnalites() {    //Fonction qui teste les differentes fonctionnalitees prise en charge par le navigateur
    document.querySelector("#geoloc").innerHTML = Modernizr.geolocation ? "pris en charge" : "non pris en charge";  //Nous regardons si la fonctionnalite de geolocalisation est prise en charge ou non et affichons le resultat
    document.querySelector("#touch").innerHTML = Modernizr.touch ? "pris en charge" : "non pris en charge" ; //Nous regardons si la fonctionnalite d'appuie sur l'ecran tactile est prise en charge ou non et affichons le resultat
    document.querySelector("#svg").innerHTML = Modernizr.svg ? "pris en charge" : "non pris en charge"; //Nous regardons si la fonctionnalite SVG est prise en charge ou non et affichons le resultat
    document.querySelector("#canvas").innerHTML = Modernizr.canvas ? "pris en charge" : "non pris en charge"; //Nous regardons si la fonctionnalite Canvas est prise en charge ou non et affichons le resultat
}

window.onload = testFonctionnalites;    //On lance la fonction testFonctionnalites lors du chargement de la page
    