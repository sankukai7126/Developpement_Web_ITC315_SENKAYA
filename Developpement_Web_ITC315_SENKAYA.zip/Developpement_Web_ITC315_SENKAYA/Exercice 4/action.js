
function initialize() {     
    var bSupportsLocal = (('localStorage' in window) && window['localStorage'] !== null);   //On stock dans une variable boolean si le stockage local est disponible

    if (!bSupportsLocal) {      //Si le stockage interne est indisponible
        document.getElementById('infoform').innerHTML = "<p>Désolé, ce navigateur ne supporte pas l’API Web Storage du W3C.</p>";   //On affiche un message d'erreur
        return; //On arrete le programme
    }

    if (window.localStorage.length != 0) {      //Si le stockage interne n'est pas nul
        document.getElementById('firstName').value = window.localStorage.getItem('firstName');  //On affiche la valeur enregistrer dans la variable firstName
        document.getElementById('lastName').value = window.localStorage.getItem('lastName');    //On affiche la valeur enregistrer dans la variable lastName
        document.getElementById('postCode').value = window.localStorage.getItem('postCode');    //On affiche la valeur enregistrer dans la variable postCode
    }

}

function storeLocalContent(fName, lName, pCode) {   //Fonction qui va servir a enregistrer les valeurs des champs de texte 
    window.localStorage.setItem('firstName', fName);    //On enregistre dans une variable ce qu'il y a dans la section firstName
    window.localStorage.setItem('lastName', lName);     //On enregistre dans une variable ce qu'il y a dans la section lastName
    window.localStorage.setItem('postCode', pCode);     //On enregistre dans une variable ce qu'il y a dans la section postCode
}

function clearLocalContent(fName, lName, pCode) {   //Fonction qui efface les valeurs sauvegardees
    window.localStorage.clear(); //On supprime les valeurs sauvegardees dans le stockage local
}


window.onload = initialize;     //On lance la fonction initialize lors du chargement de la page


