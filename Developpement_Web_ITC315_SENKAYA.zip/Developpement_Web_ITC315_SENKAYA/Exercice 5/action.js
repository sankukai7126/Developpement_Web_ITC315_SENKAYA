

function getLocation() {    

    if (Modernizr.geolocation) {    //On verifie si la geolocalisation est activee ou non
        navigator.geolocation.getCurrentPosition(geoSuccess, geoError);     //On active une des deux fonctions en fonction de l'etat de la geolocalisation
    }

}

//Fonction qui est utilisee si la geolocalisation est activee
function geoSuccess(positionInfo) {     //Fonction qui prend en parametre la position donnee par la geolocalisation
    document.getElementById("longitude").innerHTML = positionInfo.coords.longitude; //On affiche la longitude sur la page HTML
    document.getElementById("latitude").innerHTML = positionInfo.coords.latitude;   //On affiche la latitude sur la page HTML
    document.getElementById("precision").innerHTML = positionInfo.coords.accuracy;  //On affiche la precision sur la page HTML
    document.getElementById("altitude").innerHTML = positionInfo.coords.altitude;   //On affiche l'altitude sur la page HTML
    document.getElementById("precisionAltitude").innerHTML = positionInfo.coords.altitudeAccuracy;  //On affiche la precision de l'altitude sur la page HTML
    document.getElementById("cap").innerHTML = positionInfo.coords.heading; //On affiche le cap sur la page HTML
    document.getElementById("vitesse").innerHTML = positionInfo.coords.speed;   //On affiche la vitesse sur la page HTML

    var cordESIREM = {latitude: 47.3121519, longitude: 5.0039326};  //On enregistre la latitude et la longitude de l'ESIREM dans une variable

    document.getElementById("distance").innerHTML = calculDistance(positionInfo.coords, cordESIREM)+" km";  //On appelle la fonction calcul Distance en passant en parametre la fonction calculDistance en donnant la longitude et la latitude de l'ESIREM et on affiche le resultat

}
//Fonction qui est utilisee si la geolocalisation est desactivee 
function geoError(positionError) {  //On choisi le message d'erreur que l'on affiche dans l'alerte en fonction de l'erreur retourner par l'API 
    if (errorInfo.code == 1)    
    alert("L’utilisateur ne souhaite pas partager sa position");
    else if (errorInfo.code == 2)
    alert("Impossible de déterminer une position");
    else if (errorInfo.code == 3)
    alert("Délai de recherche de position trop long");
}

function calculDistance(startCoords, destCoords) {  //Calcul de la distance en deux coordonnee
    var startLatRads = degreesEnRadians(startCoords.latitude);      //On transforme en radian la latitude du depart
    var startLongRads = degreesEnRadians(startCoords.longitude);    //On transforme en radian la longitude du depart
    var destLatRads = degreesEnRadians(destCoords.latitude);        //On transforme en radian la latitude de la destination
    var destLongRads = degreesEnRadians(destCoords.longitude);      //On transforme en radian la longitude de la destination
    var Radius = 6371; // rayon de la Terre en km
    var distance = Math.acos(Math.sin(startLatRads) * Math.sin(destLatRads) + Math.cos(startLatRads) * Math.cos(destLatRads) * Math.cos(startLongRads - destLongRads)) * Radius;
    return distance;    //On retourne la distance
}

function degreesEnRadians(degrees) {        //Fonction de conversion de degree en radian
    radians = (degrees * Math.PI)/180;
    return radians;
}


window.onload = getLocation;       //On lance la fonction getLocation au chargement de la page


